vti_encoding:SR|utf8-nl
vti_author:SR|NDUBUISI\\user
vti_modifiedby:SR|NDUBUISI\\user
vti_timelastmodified:TR|21 Sep 2016 20:34:54 -0000
vti_timecreated:TR|21 Sep 2016 20:34:54 -0000
vti_cacheddtm:TX|21 Sep 2016 20:34:54 -0000
vti_filesize:IR|5200
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|account.html index.html
